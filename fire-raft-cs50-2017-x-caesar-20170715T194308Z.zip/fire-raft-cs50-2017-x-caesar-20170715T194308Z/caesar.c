#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include<stdlib.h>
#include <ctype.h>
int main(int argv, string args[])
{
    if ( argv != 2 )    
    {
    printf ("Usage: Enter the Key correctly\n");
    return 1;
    }
    printf("plaintext: ");
    string str=get_string();
    int string_key=atoi(args[1]);
    printf("ciphertext: ");
    for(int i=0, l=strlen(str);i<l;i++)
    {
        if(isalpha(str[i]))
        {
            if(isupper(str[i]))
            {
                printf("%c",((((str[i])-65)+string_key)%26)+65);
            }
            else if(islower(str[i]))
            {
                printf("%c",((((str[i])-97)+string_key)%26)+97);
            }
        }
        else
        {
            printf("%c",str[i]);
        }
        
    }
   printf("\n");
}
#include<stdio.h>
#include<cs50.h>
int main(void)
{
int steps,i,j,k;
do
{
    printf("Height: ");
steps=get_int();
if(steps==0)
return 0;
}while(steps<0 || steps>23);
for( i = 0; i < steps; i++) 
{
for( j = 0; j < steps-i-1; j++)
printf("%s", " ");
for( k = 0; k < i+2; k++)
printf("#");
printf("\n");
}	
return 0;
}
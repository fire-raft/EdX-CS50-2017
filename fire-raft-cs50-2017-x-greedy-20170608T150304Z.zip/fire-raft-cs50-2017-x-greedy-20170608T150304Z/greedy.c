#include<stdio.h>
#include<cs50.h>
#include<math.h>
int main(void)
{
    float amount;
    int amt;
    int quarter=0,dime=0,nickel=0,pennies=0,total=0;
    do
    {
        printf("O hai! How much change is owed?");
        amount=get_float();
        if(amount == 0||amount <= 0)
        printf("How much change is owed?\n");
    }while(amount<0);
    amt = (int)round(amount*100);
    quarter=amt/25;
    amt=amt%25;
    dime=amt/10;
    amt=amt%10;
    nickel=amt/5;
    amt=amt%5;
    pennies=amt;
    total=quarter+nickel+dime+pennies;
    printf("%d\n",total);
}